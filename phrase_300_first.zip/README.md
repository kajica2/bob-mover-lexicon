# 300 common jazz phrases

Generated from the local Weimar Jazz Database cache.

- phrases: 300
- files: `mxl/phrase-001.mxl` … `mxl/phrase-300.mxl`
- length: 2–4 bars in 4/4
- allowed note values: quarter, eighth, eighth-note triplet
- ranking: distinct source solo count first, then candidate occurrences

See `metadata.json` for the contour, frequency, source solo, and
transposition metadata for every phrase.
